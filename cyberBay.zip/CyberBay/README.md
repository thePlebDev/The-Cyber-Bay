# Cyber Bay for Android


### Current Status

This project is in its early infancy state.

Want to help build something great. We're actively looking for contributors to help develop this pre-release alpha into something amazing. This is a great time to get involved and help shape the future of Cyber Bay!

Also, important to note: this is a side-project worked on during spare time. We appreciate any bug reports, but realistically we may not be able to fix issues in a timely manner (feel free to contribute fixes though!)

### Contributing
Cyber Bay has an active community of contributors and collaborators that enjoy working together to continuously improve the application's form and function. If you would like to get involved, have a look at our [Contributing Guide](CONTRIBUTING.md)!
